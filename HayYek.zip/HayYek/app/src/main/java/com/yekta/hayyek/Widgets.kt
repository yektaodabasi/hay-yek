package com.yekta.hayyek

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.widget.RemoteViews

object Widgets {
    private val tileIds = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3)

    fun updateAll(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        update4(c, m, m.getAppWidgetIds(ComponentName(c, Widget4Provider::class.java)))
        update2(c, m, m.getAppWidgetIds(ComponentName(c, Widget2Provider::class.java)))
        Scheduler.scheduleTick(c)
    }

    private fun sizeDp(m: AppWidgetManager, id: Int, defW: Int, defH: Int): Pair<Int, Int> {
        val o = m.getAppWidgetOptions(id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, defW)
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, defH)
        return Pair(if (w > 0) w else defW, if (h > 0) h else defH)
    }

    fun update4(c: Context, m: AppWidgetManager, ids: IntArray) {
        val d = c.resources.displayMetrics.density
        for (id in ids) {
            val (wDp, hDp) = sizeDp(m, id, 250, 110)
            val tileW = ((wDp - 12 - 9) / 4f * d).toInt()
            val tileH = ((hDp - 12 - 32 - 4) * d).toInt().coerceAtLeast((40 * d).toInt())
            val rv = RemoteViews(c.packageName, R.layout.widget_4x2)
            for (i in Buildings.list.indices) {
                rv.setImageViewBitmap(tileIds[i], Render.tile(c, i, tileW, tileH))
                rv.setOnClickPendingIntent(tileIds[i], Scheduler.tilePi(c, i))
            }
            rv.setTextViewText(R.id.sub, Render.summary(c))
            rv.setOnClickPendingIntent(R.id.night, Scheduler.nightPi(c))
            rv.setOnClickPendingIntent(R.id.title_block, Scheduler.gamePi(c))
            m.updateAppWidget(id, rv)
        }
    }

    fun update2(c: Context, m: AppWidgetManager, ids: IntArray) {
        val d = c.resources.displayMetrics.density
        for (id in ids) {
            val (wDp, hDp) = sizeDp(m, id, 110, 110)
            val rv = RemoteViews(c.packageName, R.layout.widget_2x2)
            rv.setImageViewBitmap(R.id.img, Render.card(c, (wDp * d).toInt(), (hDp * d).toInt()))
            rv.setOnClickPendingIntent(R.id.root, Scheduler.appPi(c))
            m.updateAppWidget(id, rv)
        }
    }
}

class Widget4Provider : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        Widgets.update4(c, m, ids)
        Scheduler.scheduleTick(c)
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, newOptions: Bundle) {
        Widgets.update4(c, m, intArrayOf(id))
    }
}

class Widget2Provider : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        Widgets.update2(c, m, ids)
        Scheduler.scheduleTick(c)
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, newOptions: Bundle) {
        Widgets.update2(c, m, intArrayOf(id))
    }
}
