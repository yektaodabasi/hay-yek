package com.yekta.hayyek

import android.content.Context

data class Building(val name: String, val short: String, val defDay: Int, val defNight: Int)

object Buildings {
    val list = listOf(
        Building("Tarla", "Tarla", 20, 240),
        Building("Fırın", "Fırın", 15, 240),
        Building("Süt fabrikası", "Süt", 30, 240),
        Building("Şeker değirmeni", "Şeker", 20, 240)
    )
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("hay", Context.MODE_PRIVATE)

    fun endAt(c: Context, i: Int): Long = sp(c).getLong("end$i", 0L)
    fun total(c: Context, i: Int): Long = sp(c).getLong("total$i", 0L)

    fun start(c: Context, i: Int, minutes: Int) {
        val ms = minutes * 60_000L
        sp(c).edit()
            .putLong("end$i", System.currentTimeMillis() + ms)
            .putLong("total$i", ms)
            .apply()
    }

    fun clear(c: Context, i: Int) {
        sp(c).edit().putLong("end$i", 0L).putLong("total$i", 0L).apply()
    }

    fun dayMin(c: Context, i: Int): Int = sp(c).getInt("day$i", Buildings.list[i].defDay)
    fun nightMin(c: Context, i: Int): Int = sp(c).getInt("night$i", Buildings.list[i].defNight)

    fun setMins(c: Context, i: Int, day: Int, night: Int) {
        sp(c).edit().putInt("day$i", day).putInt("night$i", night).apply()
    }
}
