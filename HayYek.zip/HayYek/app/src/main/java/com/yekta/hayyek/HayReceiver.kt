package com.yekta.hayyek

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

object Notifier {
    fun ready(c: Context, idx: Int) {
        if (Render.state(c, idx) != 2) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("hay", "Üretim hazır", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = Notification.Builder(c, "hay")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(Buildings.list[idx].name + " hazır")
            .setContentText("Topla ve yeniden üret")
            .setContentIntent(Scheduler.gamePi(c))
            .setAutoCancel(true)
            .build()
        nm.notify(10 + idx, n)
    }
}

class HayReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, Buildings.list.size - 1)
        when (intent.action) {
            Scheduler.ACTION_TILE -> {
                if (Render.state(c, idx) == 1) {
                    Toast.makeText(c, Buildings.list[idx].name + " devam ediyor", Toast.LENGTH_SHORT).show()
                } else {
                    Store.start(c, idx, Store.dayMin(c, idx))
                    Scheduler.scheduleDone(c, idx)
                }
            }
            Scheduler.ACTION_NIGHT -> {
                for (i in Buildings.list.indices) {
                    Store.start(c, i, Store.nightMin(c, i))
                    Scheduler.scheduleDone(c, i)
                }
                Toast.makeText(c, "Gece planı başladı", Toast.LENGTH_SHORT).show()
            }
            Scheduler.ACTION_DONE -> Notifier.ready(c, idx)
            Intent.ACTION_BOOT_COMPLETED -> Scheduler.rescheduleAll(c)
        }
        Widgets.updateAll(c)
    }
}
