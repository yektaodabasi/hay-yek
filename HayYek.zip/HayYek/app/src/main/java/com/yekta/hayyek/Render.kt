package com.yekta.hayyek

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

object Render {
    private fun col(s: String): Int = Color.parseColor(s)

    /** 0 = boşta, 1 = çalışıyor, 2 = hazır */
    fun state(c: Context, i: Int): Int {
        val end = Store.endAt(c, i)
        if (end == 0L) return 0
        return if (System.currentTimeMillis() >= end) 2 else 1
    }

    fun fmt(ms: Long): String {
        val mins = ((ms + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
        if (mins < 60) return "$mins dk"
        val h = mins / 60
        val m = mins % 60
        return if (m == 0) "${h}sa" else "${h}sa ${m}dk"
    }

    private fun fit(p: Paint, text: String, maxW: Float, start: Float) {
        p.textSize = start
        while (p.measureText(text) > maxW && p.textSize > 8f) p.textSize -= 1f
    }

    private fun nearestRunning(c: Context): Int {
        val now = System.currentTimeMillis()
        var best = -1
        var left = Long.MAX_VALUE
        for (i in Buildings.list.indices) {
            if (state(c, i) == 1) {
                val l = Store.endAt(c, i) - now
                if (l < left) {
                    left = l
                    best = i
                }
            }
        }
        return best
    }

    fun summary(c: Context): String {
        val ready = Buildings.list.indices.filter { state(c, it) == 2 }
        if (ready.isNotEmpty()) {
            return "Hazır: " + ready.joinToString(", ") { Buildings.list[it].short }
        }
        val best = nearestRunning(c)
        if (best < 0) return "Hepsi boşta"
        val left = Store.endAt(c, best) - System.currentTimeMillis()
        return "Sıradaki: " + Buildings.list[best].short + " · " + fmt(left)
    }

    private fun progress(c: Context, i: Int): Float {
        val total = Store.total(c, i)
        if (total <= 0L) return 0f
        val left = Store.endAt(c, i) - System.currentTimeMillis()
        return (1f - left.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    }

    private fun drawBar(cv: Canvas, p: Paint, x: Float, y: Float, w: Float, h: Float, frac: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = col("#E4CFA0")
        cv.drawRoundRect(RectF(x, y, x + w, y + h), h / 2, h / 2, p)
        if (frac > 0f) {
            p.color = color
            val fw = (w * frac).coerceAtLeast(h)
            cv.drawRoundRect(RectF(x, y, x + fw, y + h), h / 2, h / 2, p)
        }
    }

    fun tile(c: Context, i: Int, w: Int, h: Int): Bitmap {
        val d = c.resources.displayMetrics.density
        val bw = w.coerceAtLeast(1)
        val bh = h.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        bmp.density = c.resources.displayMetrics.densityDpi
        val cv = Canvas(bmp)
        val st = state(c, i)
        val s = (bh / d / 60f).coerceIn(0.7f, 1.2f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rad = 12f * d

        p.style = Paint.Style.FILL
        p.color = col("#FFFBEF")
        cv.drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), rad, rad, p)

        val sw = (if (st == 2) 2.5f else 1.5f) * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.color = if (st == 2) col("#3F7D20") else col("#E4CFA0")
        cv.drawRoundRect(RectF(sw / 2, sw / 2, bw - sw / 2, bh - sw / 2), rad, rad, p)

        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        val cx = bw / 2f
        val name = Buildings.list[i].short
        p.color = col("#4A2E14")
        fit(p, name, bw * 0.9f, 11f * d * s)
        cv.drawText(name, cx, bh * 0.28f, p)

        val txt: String
        val tc: Int
        when (st) {
            2 -> {
                txt = "Hazır"
                tc = col("#3F7D20")
            }
            1 -> {
                txt = fmt(Store.endAt(c, i) - System.currentTimeMillis())
                tc = col("#4A2E14")
            }
            else -> {
                txt = "Boşta"
                tc = col("#8B6B44")
            }
        }
        p.color = tc
        fit(p, txt, bw * 0.9f, 16f * d * s)
        cv.drawText(txt, cx, bh * 0.63f, p)

        val barH = 5f * d * s
        val barY = bh - 9f * d * s - barH
        val frac = when (st) {
            2 -> 1f
            1 -> progress(c, i)
            else -> 0f
        }
        val barColor = if (st == 2) col("#3F7D20") else col("#C9821A")
        drawBar(cv, p, 8f * d, barY, bw - 16f * d, barH, frac, barColor)
        return bmp
    }

    fun card(c: Context, w: Int, h: Int): Bitmap {
        val d = c.resources.displayMetrics.density
        val bw = w.coerceAtLeast(1)
        val bh = h.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        bmp.density = c.resources.displayMetrics.densityDpi
        val cv = Canvas(bmp)
        val s = (minOf(bw, bh) / d / 110f).coerceIn(0.7f, 1.4f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rad = 20f * d

        p.style = Paint.Style.FILL
        p.color = col("#FFF3D6")
        cv.drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), rad, rad, p)
        val sw = 2f * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.color = col("#8A5A2B")
        cv.drawRoundRect(RectF(sw / 2, sw / 2, bw - sw / 2, bh - sw / 2), rad, rad, p)

        val ready = Buildings.list.indices.firstOrNull { state(c, it) == 2 } ?: -1
        val running = nearestRunning(c)
        val target = if (ready >= 0) ready else running

        val label: String
        val name: String
        val big: String
        var frac = 0f
        var bigColor = col("#4A2E14")
        if (target < 0) {
            label = "Hay Day"
            name = "Hepsi boşta"
            big = "—"
        } else if (ready >= 0) {
            label = "Hazır"
            name = Buildings.list[target].name
            big = "Topla"
            frac = 1f
            bigColor = col("#3F7D20")
        } else {
            label = "Sıradaki"
            name = Buildings.list[target].name
            big = fmt(Store.endAt(c, target) - System.currentTimeMillis())
            frac = progress(c, target)
        }

        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        val cx = bw / 2f
        val maxW = bw * 0.85f

        p.color = col("#6B4620")
        fit(p, label, maxW, 11f * d * s)
        cv.drawText(label, cx, bh * 0.22f, p)

        p.color = col("#4A2E14")
        fit(p, name, maxW, 16f * d * s)
        cv.drawText(name, cx, bh * 0.42f, p)

        p.color = bigColor
        fit(p, big, maxW, 26f * d * s)
        cv.drawText(big, cx, bh * 0.70f, p)

        val barH = 7f * d * s
        val barColor = if (ready >= 0) col("#3F7D20") else col("#C9821A")
        drawBar(cv, p, 16f * d, bh - 14f * d * s - barH, bw - 32f * d, barH, frac, barColor)
        return bmp
    }
}
