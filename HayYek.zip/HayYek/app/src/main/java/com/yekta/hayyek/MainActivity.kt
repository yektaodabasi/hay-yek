package com.yekta.hayyek

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val dayFields = ArrayList<EditText>()
    private val nightFields = ArrayList<EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(36), dp(20), dp(32))
        root.setBackgroundColor(Color.parseColor("#FFF3D6"))

        fun text(t: String, size: Float, bold: Boolean, color: String): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setTextColor(Color.parseColor(color))
            if (bold) tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
            return tv
        }

        root.addView(text("HayYek", 26f, true, "#4A2E14"))
        val info = text(
            "Süreleri dakika olarak gir. Widget'ta bir binaya dokununca gündüz süresiyle geri sayım başlar. " +
                "Gece planı düğmesi hepsini gece süresiyle başlatır. Hazır olan binaya tekrar dokunursan yeniden başlar.",
            14f, false, "#6B4620"
        )
        info.setPadding(0, dp(8), 0, dp(16))
        root.addView(info)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val h0 = text("Bina", 13f, true, "#4A2E14")
        h0.width = dp(120)
        val h1 = text("Gündüz (dk)", 13f, true, "#4A2E14")
        h1.width = dp(90)
        val h2 = text("Gece (dk)", 13f, true, "#4A2E14")
        h2.width = dp(90)
        head.addView(h0)
        head.addView(h1)
        head.addView(h2)
        root.addView(head)

        for (i in Buildings.list.indices) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val name = text(Buildings.list[i].name, 15f, false, "#4A2E14")
            name.width = dp(120)
            val day = EditText(this)
            day.inputType = InputType.TYPE_CLASS_NUMBER
            day.setText(Store.dayMin(this, i).toString())
            day.width = dp(90)
            val night = EditText(this)
            night.inputType = InputType.TYPE_CLASS_NUMBER
            night.setText(Store.nightMin(this, i).toString())
            night.width = dp(90)
            dayFields.add(day)
            nightFields.add(night)
            row.addView(name)
            row.addView(day)
            row.addView(night)
            root.addView(row)
        }

        val save = Button(this)
        save.text = "Kaydet"
        save.setOnClickListener {
            for (i in Buildings.list.indices) {
                val dm = dayFields[i].text.toString().toIntOrNull()?.coerceIn(1, 10080) ?: Buildings.list[i].defDay
                val nm = nightFields[i].text.toString().toIntOrNull()?.coerceIn(1, 10080) ?: Buildings.list[i].defNight
                Store.setMins(this, i, dm, nm)
            }
            Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
        }
        root.addView(save)

        val play = Button(this)
        play.text = "Hay Day'i aç"
        play.setOnClickListener { startActivity(Scheduler.gameIntent(this)) }
        root.addView(play)

        val reset = Button(this)
        reset.text = "Tüm sayaçları sıfırla"
        reset.setOnClickListener {
            for (i in Buildings.list.indices) Store.clear(this, i)
            Widgets.updateAll(this)
            Toast.makeText(this, "Sayaçlar sıfırlandı", Toast.LENGTH_SHORT).show()
        }
        root.addView(reset)

        val note = text(
            "Widget eklemek için ana ekranda boş yere uzun bas, Widget'lar bölümünden HayYek'i seç.",
            13f, false, "#6B4620"
        )
        note.setPadding(0, dp(16), 0, 0)
        root.addView(note)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        Scheduler.rescheduleAll(this)
        Widgets.updateAll(this)
    }
}
