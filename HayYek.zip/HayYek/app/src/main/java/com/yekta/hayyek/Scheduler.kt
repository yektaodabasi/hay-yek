package com.yekta.hayyek

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri

object Scheduler {
    const val ACTION_TILE = "com.yekta.hayyek.TILE"
    const val ACTION_NIGHT = "com.yekta.hayyek.NIGHT"
    const val ACTION_DONE = "com.yekta.hayyek.DONE"
    const val ACTION_TICK = "com.yekta.hayyek.TICK"
    const val GAME = "com.supercell.hayday"

    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun bc(c: Context, action: String, idx: Int, code: Int): PendingIntent {
        val i = Intent(c, HayReceiver::class.java).setAction(action).putExtra("idx", idx)
        return PendingIntent.getBroadcast(c, code, i, FLAGS)
    }

    fun tilePi(c: Context, idx: Int): PendingIntent = bc(c, ACTION_TILE, idx, 300 + idx)
    fun nightPi(c: Context): PendingIntent = bc(c, ACTION_NIGHT, 0, 400)

    fun gameIntent(c: Context): Intent {
        val launch = c.packageManager.getLaunchIntentForPackage(GAME)
        if (launch != null) return launch
        return Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GAME"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun gamePi(c: Context): PendingIntent = PendingIntent.getActivity(c, 500, gameIntent(c), FLAGS)
    fun appPi(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 501, Intent(c, MainActivity::class.java), FLAGS)

    private fun am(c: Context): AlarmManager = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleDone(c: Context, idx: Int) {
        val end = Store.endAt(c, idx)
        if (end > System.currentTimeMillis()) {
            am(c).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, bc(c, ACTION_DONE, idx, 100 + idx))
        }
    }

    fun rescheduleAll(c: Context) {
        for (i in Buildings.list.indices) scheduleDone(c, i)
    }

    fun scheduleTick(c: Context) {
        val any = Buildings.list.indices.any { Render.state(c, it) == 1 }
        val pi = bc(c, ACTION_TICK, 0, 200)
        if (any) {
            am(c).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60_000L, pi)
        } else {
            am(c).cancel(pi)
        }
    }
}
